HDDHackr v1.40 Build 20130303

** Notes **
-------------

- HDDHackr is made only for real MS-DOS, not for windows command prompt or even windows XP/Vista/7 !!!!
- 99% of problems appears to be Mainboard chipset (SATA Chipset) or some BIOS configurations (RAID, AHCI, LegacyIDE, ...), not HDDHackr app!!
- Use "Bootable_USB_Drive_Creator_Tool" to prepare USB drive to boot into MS-DOS.
- Download package contains approx. 70 recovery files (UNDO.BIN)



Works with the following Western Digital drive series: [BEAS/BEVS/BEVT/BPVT/LPVT/BEKT/BJKT/BPKT/BUDT/HLFS/BLFS]

- WD Scorpio Series BEAS/BEVS
						WD600BEAS  -  60GB
						WD800BEAS  -  80GB
						WD1000BEAS - 100GB
						WD1200BEAS - 120GB
						WD1600BEAS - 160GB
						WD2000BEAS - 200GB
						WD2500BEAS - 250GB
						WD600BEVS  -  60GB
						WD800BEVS  -  80GB
						WD1000BEVS - 100GB
						WD1200BEVS - 120GB
						WD1600BEVS - 160GB
						WD2000BEVS - 200GB
						WD2500BEVS - 250GB
						
- WD Scorpio Blue Series BEVS/BEVT/BPVT/LPVT
						WD3200BEVS - 320GB
						WD600BEVT  -  60GB
						WD800BEVT  -  80GB
						WD1200BEVT - 120GB
						WD1600BEVT - 160GB
						WD2000BEVT - 200GB
						WD2500BEVT - 250GB
						WD3200BEVT - 320GB
						WD4000BEVT - 400GB
						WD5000BEVT - 500GB
						WD6400BEVT - 640GB
						WD1600BPVT - 160GB
						WD2500BPVT - 250GB
						WD3200BPVT - 320GB
						WD5000BPVT - 500GB
						WD6400BPVT - 640GB
						WD7500BPVT - 750GB
						WD2500LPVT - 250GB
						WD3200LPVT - 320GB
						WD5000LPVT - 500GB
						WD10TPVT   -   1TB
						
- WD Scorpio Black Series BEKT/BJKT/BPKT
						WD800BEKT  -  80GB
						WD1200BEKT - 120GB
						WD1600BEKT - 160GB
						WD2500BEKT - 250GB
						WD3200BEKT - 320GB
						WD5000BEKT - 500GB
						WD800BJKT  -  80GB
						WD1200BJKT - 120GB
						WD1600BJKT - 160GB
						WD3200BJKT - 320GB
						WD5000BJKT - 500GB
						WD3200BPKT - 320GB
						WD5000BPKT - 500GB
						WD7500BPKT - 750GB

- WD AV-25 Series BUDT
						WD1600BUDT - 160GB
						WD2500BUDT - 250GB
						WD3200BUDT - 320GB
						WD5000BUDT - 500GB
				
- WD VelociRaptor Series HLFS/BLFS
						WD1500HLFS - 150GB
						WD1600HLFS - 160GB
						WD3000HLFS - 300GB
						WD1500BLFS - 150GB
						WD1600BLFS - 160GB
						WD3000BLFS - 300GB
						
						
						
						
Version History
-----------------
(v1.40)
* Updated SATA and PATA controller list
* Added support for 320GB and 500GB hard drives (HDDSS.BIN required)
* Added support to adjust Idle Timer (IntelliPark)
* Confirmed HddHacker supports hard drives manufactured till 2013


(v1.30)
* SATA and IDE port scan improved
  (The ports are now enumerated with the CONFIG_ADDRESS and CONFIG_DATA register instead of using interrupts)
* PATA and SATA controller list updated
* Automatic Device Reset
* Code optimization to work with modern SATA2 controllers added
  (Remember to set SATA controllers to IDE and not AHCI mode)
  
(v1.25)
* Extended Modelnumber String detection
  (new hard drives have two Modelnumber strings)

(v1.24)
* Fixed issue with LBA 28/48-bit address comparison
* Confirmed HddHacker supports hard drives manufactured 2010
  - WD Scorpio Blue	Series BPVT
  - WD AV-25		Series BUDT

(v1.22)
* Added support for the Western Digital Scorpio Series manufactured 2009

(v1.20)
* Fixed issue with Intel ICH9, ICH10 and VIA chipsets
* Implemented progress bar
* Added support for 80GB and 250GB HDDs (HDDSS.BIN required)

(v1.11)
* Fixed issue, that sometimes caused flashing of Model Name to incorrect offset.

(v1.10)
* Added option to create Partitions 0/2/3 (no more manual hex editing)
* Bug fixed, that caused errors like "LBA size does not match"
* Improved compatibility
* Minor changes

(v1.00)
* Completely new version core
* Two flashing modes, Auto and Manual
* Western Digital Vendor Intro Power Brute for misflashed drives
* Minimized incompatibility problems
* Improved exception handling
* Confirmed HddHacker supports
  - WD Scorpio       Series BEVS/BEAS
  - WD Scorpio Blue  Series BEVS/BEVT
  - WD Scorpio Black Series BEKT/BJKT
  - WD VelociRaptor  Series

(v0.91B)
* Changed restore command to -r "HddHacker -r"
* Changed appearance for more read comfort.
* Changed from .COM to .EXE

(v0.91)
* Added support for the WD BEVS "RST" HDD series and maybe some others.

(v0.90)
* Support for WD 120GB Hard Drives  
* Supports ONLY the WD BEVS 'LAT' version!

(v0.82B)
* Added option to flash the Western Digital back to its original state
* Improved no more manual copying of sectors
* Improved compatibility, should now really work with all BEVS models
* Bug fixed, that caused flashing of incorrect serial number in some rare cases.

(v0.50B)
* Initial Version



How to use
------------

HddHacker supports two flashing modes, Auto and Manual. Typing HDDHackr at a DOS prompt
will start auto mode. In auto mode all hard drives will be detected automatically.
In manual mode you can enter all the parameters used for flashing by hand.

The following help screen is displayed if you start HddHacker with a wrong number of
arguments:

HDDHackr [C|D|F|R] [PORT] [DRIVE POS] [SECTOR FILE] [RESTORE FILE]
                C: Create Partitions 0/2/3
                D: Dump sector 16-22 from XBOX360 HDD to file
                F: Flash Western Digital firmware
                R: Restore Western Digital firmware
             PORT: Port to send command to e.g. 09F0
        DRIVE POS: A0 for Master, B0 for Slave
      SECTOR FILE: Sector dump file e.g. HDDSS.BIN
     RESTORE FILE: Firmware restore file e.g. UNDO.BIN

Example for create, dump, flash and restore:
HDDHackr C 09F0 A0
HDDHackr D 09F0 A0 HDDSS.BIN
HDDHackr F 09F0 A0 HDDSS.BIN UNDO.BIN
HDDHackr R 09F0 A0 UNDO.BIN



Explanation of the Parameters
-------------------------------

[C|D|F|R]
---------
- this will set the mode of operation, it is recommended to first try to dump the XBOX360
  hard drive data, if the dump will fail, it is highly unlikely that a flash or restore
  will succeed on the Western Digital drive

[PORT]
--------
- the port to which the Hard Drive is connected, a port number should always be entered
  in hexadecimal and have 4 hex digits, valid ports are: 01F0, 09F0, .....
- this option can be used if your PCI adapter card or on board SATA ports are
  not identified by the auto mode

[DRIVE POS]
-------------
- on SATA ports this value is always A0, cause you can only connect a master drive to
  a SATA port, so for SATA you will always type A0 here

[SECTOR FILE]
---------------
- name of the sector 16-22 dump file better known as HDDSS.BIN

[RESTORE FILE]
----------------
- name of the firmware restore file e.g. UNDO.BIN



Using HddHacker in auto or manual mode
--------------------------------

* Dumping the HDDSS.BIN file *
Boot to MS-DOS from a writeable medium (like a floppy or UBS Stick).
Connect an *original* Xbox360 HDD to your SATA controller. Make sure it is the only
SATA device that is connected. Now run 'HDDHackr D [PORT] A0 HDDSS.BIN' and it will create
the file 'HDDSS.BIN' and save it to the path you've started HddHacker from.

* Creating Partitions 0/2/3 *
The Partition 0/2/3 will be created to make the drive compatible with "Xplorer360" and XBOX360 Console.
In manual-mode you have to type 'HDDHackr C [PORT] A0'.

* Flashing your Western Digital drive *
Turn off your PC and connect the Western Digital hard drive. Boot to MS-DOS again.
Type 'HDDHackr F [PORT] A0 HDDSS.BIN UNDO.BIN' from the same path you have saved the HDDSS.BIN
file to. This will create an 'UNDO.BIN' file that you need if you want to undo the hack
and flash your firmware back to the original state.

* Restoring your WD to original state *
If you don't want to use your modded WD HDD in your XBOX360 anymore and you want to
flash it back to its original size/state, then you can now do so. Boot to MS-DOS and 
run 'HDDHackr R [PORT] A0 UNDO.BIN'. This will use the UNDO.BIN file you created before to 
restore the drive to its original state.

* Vendor Intro Power Brute for misflashed drives *
To enter the recovery mode you should boot to MS-DOS, connect your hard drive to PC and type
'HDDHackr R [PORT] A0 UNDO.BIN'. If the hard drive is misflashed you will be prompted with:
"Western Digital Vendor Intro failed on port [PORT]"
"Do you want to resend the command until the drive responds (Y/N)?"
Press YES, disconnect the hard drive from power and connect it again.
You should get Status 0x50 and the drive will be reflashed.

* Adjust IntelliPark Timer, WD only *
IntelliPark is not that intelligent. In fact, with default settings it parks the heads
after 8 seconds of inactivity. This means, depends of your OS and usage pattern the drive will reach
it's designed lifetime in very short time. Meaning of IntelliPark values.
Resolution is 0.1 seconds from 0.1 to 12.8 seconds.
Resolution is 30.0 seconds from 30.0 to 3810.0 seconds.
Note, times between 12.8 and 30.0 seconds will be set to 30.0 seconds.
Default timer is 8.0 seconds, recommended timer is 300.0 seconds.
To disable timer type 0 seconds.


FAQ
-----

Q. Is it true that in several cases, booting PC with connected HDD 
will change LBA size of my hard drive and it will no longer work in x360?
A. Yes, most modern mainboard/BIOS manufacturer modify LBA size,
they cut the harddrive for HPA and store additional BIOS data at the end of a hard disk.
So if you have such mainboard that uses this technology, do not have the a hard drive
powered on during BIOS detection, it will break XBOX360 compatibility.
To get the x360 compatibility back, simply reflash the HDDSS.BIN.


Q. I heard lot of people having problems with the new 2010/2011 models.
Does it matter wich moddel I have????
A. The 2010/2011 drive are the same, lots of people have hacked them perfectly.
99% of problems appear to be SATA chipset or BIOS configuration.


Q. Will this tool allow me to connect a 500GB drive to my x360 ?
A. No. The information on sector 16 is signed and can't be changed. You can 
only use the size where you have a valid signature for. In otherwords, if a 
bigger HDD comes out, then you can use that signature.


Q. With which HDD's does this work ?
A. As of version 1.40, it now works with all sizes and versions of the
WesternDigital Scorpio Series. 


Q. Do I need the same size WD HDD as the size on sector 16 states ?
A. No. You can use bigger HDD's, but you can't use more than the size stated 
in sector 16. You can NOT use smaller HDD's than the size on sector 16 states.
For example, you can use a 40GB HDD with a sector 16 from a 20GB HDD, but 
not the other way around of course.


Q. Can I use the HDD in my PC again ?
A. Of course. The tool comes with an 'restore' option, that will restore the 
original size. For example, you use a 40GB WD HDD, you used HDDSS.BIN from
a valid xbox360 20GB HDD, so the tool will transform your 40GB HDD into a 20GB HDD.
However, you can restore it to 40GB anytime you want with the restore option.


Q. I lost my UNDO.BIN file, can I use it from another drive ?
A. There's no guarantee this will work. It might kill your drive.
Using a UNDO.BIN from a different model (e.g. LAT/RST) will kill your drive for sure.


Q. I have a XBOX360 Core/Arcade/Slim version and want to use this hack to buy a cheap HDD. 
But how do i connect it ?
A. If you don't have a Premium/Elite/Slim, you can make the HDD internal. One great tutorial
that will show you how to do this: http://www.xboxhacker.net/index.php?topic=9542.0


Q. The tool doesn't detect my HDD !
A. First, make sure you are running it from real MS-DOS, not from a DOS box under windows. 
If the HddHacker does not autodetect your SATA controller then let us know about it.


Q. The HddHacker says the UNDO.BIN file already exists.
A. If you previously made an UNDO.BIN file, then you should keep that one. There's no 
need to create another one. Keep in mind that the UNDO.BIN represents the current state
of the drive.


Q. Could you do this for my Seagate, Maxtor, Samsung or whatever drive too ?
A. Yes, but I don't have plans to do so. It is a lot of work to convert this tool
for usage with other brands and don't think it is worth the trouble.


Q. Where can I donate ? 
A. Nowhere. Just enjoy!



Thanks and greetings to all participants!
- Team MODFREAKz for initial logic board experiments
- Loser for his findings on the sector 16-22
- Antman1 and Rutger1413 for supplying info about the new 120GB signature
- thethinker_uk for supplying an RST hard drive
- LordX for his tones of chipset tests
- Homer2102 for supplying a x360 with vulnerable kernel and everybody else at XS/XBH.  


Special thanks to TheSpecialist for his excellent assembler app!

Modfreakz and Schtrom in March 2013

