﻿//*************************************************************
//  Filename:       XuiExtensionParse.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Class used to parse XUI Extension files.
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections;
using System.Windows;
using System.Windows.Forms;

namespace XuiWorkshop
{
    class XmlExtensionParse
    {
        private string curTag;

        public List<XUI_CLASS> readExtension(string filePath)
        {
            XmlTextReader readXml = new XmlTextReader(filePath);
            List<XUI_CLASS> xmlClasses = new List<XUI_CLASS>();
            XUI_CLASS tmpClass = default(XUI_CLASS);
            XUIELEM_PROP_DEF tmpPropDef = default(XUIELEM_PROP_DEF);

            try
            {
                while (readXml.Read())
                {
                    switch (readXml.NodeType)
                    {
                        case XmlNodeType.Element:
                            if (readXml.Name == "XUIClass")
                            {
                                tmpClass.szClassName = readXml.GetAttribute("Name");
                                tmpClass.szBaseClassName = readXml.GetAttribute("BaseClassName");

                                tmpClass.PropDefs = new List<XUIELEM_PROP_DEF>();
                                tmpClass.dwPropDefCount = 0;
                            }
                            else if (readXml.Name == "PropDef")
                            {
                                // Reset Values
                                tmpPropDef = default(XUIELEM_PROP_DEF);

                                // Assign values from xml
                                tmpPropDef.PropName = readXml.GetAttribute("Name");
                                tmpPropDef.Type = Xui._GetPropType(readXml.GetAttribute("Type"));
                                tmpPropDef.Id = Convert.ToInt32(readXml.GetAttribute("Id"));

                                if(readXml.GetAttribute("Flags") != null)
                                    tmpPropDef.Flags = Xui._GetFlagType(readXml.GetAttribute("Flags"));
                            }
                            else if (readXml.Name == "DefaultVal")
                                curTag = readXml.Name;
                            break;
                        case XmlNodeType.Text:
                            if (curTag == "DefaultVal")
                            {
                                tmpPropDef.DefaultVal = readXml.Value; // Will be read in as string
                            }
                            break;
                        case XmlNodeType.EndElement:
                            if (readXml.Name == "PropDef")
                            {
                                // Add Property
                                tmpClass.PropDefs.Add(tmpPropDef);
                                tmpClass.dwPropDefCount++;
                            }
                            if (readXml.Name == "XUIClass")
                            {
                                xmlClasses.Add(tmpClass);
                            }
                            break;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message, "File Error", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }

            // Close xml reader
            readXml.Close();

            return xmlClasses;
        }
    }
}
