﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using WeifenLuo.WinFormsUI.Docking;

namespace XuiWorkshop
{
    public partial class FormXui : DockContent
    {
        // This is to hold the currently selected object in .xui view
        private XUIOBJECTDATA xuiObject;
        private XUIOBJECTDATA currentObject;

        public FormXui(XUIOBJECTDATA baseObject)
        {
            xuiObject = baseObject;

            InitializeComponent();

            // Show our Xui Info Tree
            BuildTreeView();

            // Build Properties Panel
            Form1.Instance.formPROPERTIES = new FormProperties();
            Form1.Instance.formPROPERTIES.Show(Form1.Instance.parentPanel);
            Form1.Instance.propertiesToolStripMenuItem.Checked = true;

            // Build Timeline Panel
            Form1.Instance.formTIMELINES = new FormTimelines();
            Form1.Instance.formTIMELINES.Show(Form1.Instance.parentPanel);
            Form1.Instance.timelinesToolStripMenuItem.Checked = true;
        }

        public void BuildTreeView()
        {
            menu_TreeView.Nodes.Clear();
            string rootId = xuiObject.GetPropVal("Id").ToString();
            TreeNode rootNode;
            if(rootId != "")
                rootNode = new TreeNode(xuiObject.GetPropVal("Id").ToString());
            else
                rootNode = new TreeNode(xuiObject.ClassName);

            menu_TreeView.Nodes.Add(rootNode);

            foreach (XUIOBJECTDATA data in xuiObject.ChildrenArray)
            {
                AddNode(data, ref rootNode);
            }
        }

        private void AddNode(XUIOBJECTDATA data, ref TreeNode node)
        {
            string id = data.GetPropVal("Id").ToString();
            TreeNode childNode = new TreeNode(data.ClassName + " - " + id);

            foreach (XUIOBJECTDATA childData in data.ChildrenArray)
            {
                AddNode(childData, ref childNode);
            }

            node.Nodes.Add(childNode);
        }

        private void menu_TreeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode tempNode = new TreeNode();

            tempNode = menu_TreeView.SelectedNode;

            if (tempNode.Level > -1)
            {
                // Build a list of parent strings
                string[] pathSplit = tempNode.FullPath.Split('\\');
                string heriarchyId = "";
                foreach (string tmp in pathSplit)
                {
                    string[] temp = tmp.Split(' ');

                    // Hack fix for xur built by older version of the workshop
                    if (temp[temp.Length - 1] == "XuiCanvas0")
                        temp[temp.Length - 1] = "XuiCanvas";

                    heriarchyId += temp[temp.Length - 1] + "#";
                }

                heriarchyId = heriarchyId.Substring(0, heriarchyId.Length - 1); // Remove extra #

                // Get XUIOBJECTDATA for Selected Item
                currentObject = xuiObject.GetObjectByHeriarchyId(heriarchyId);

                if (currentObject == null)
                {
                    Console.WriteLine("Load object failed");
                    return;
                }

                // Update Property List
                Form1.Instance.formPROPERTIES.UpdatePropertyList(currentObject.PropertyArray);

                // Update Timeline List
                Form1.Instance.formTIMELINES.CreateTimeLines(currentObject.SubTimelines, currentObject.NamedFrameArray);
            }
        }
    }
}
