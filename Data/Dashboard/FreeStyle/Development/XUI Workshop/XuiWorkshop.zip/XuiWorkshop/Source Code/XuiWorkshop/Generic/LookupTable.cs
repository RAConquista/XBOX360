﻿//*************************************************************
//  Filename:       LookupTable.cs
//  Author:         Unknown
//  Date:           Unknown
//  Description:    Template class to create a lookuptable
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XuiWorkshop
{
    public class LookupTable<T> : List<T>
    {
        public int GetIndex(T entry)
        {
            // If the return value is -1, then there was an error
            int index = IndexOf(entry);
            if (index == -1)
            {
                Add(entry);
                index = IndexOf(entry);
            }
            return index;
        }
        public int GetIndex(List<T> sublist, int start = 0)
        {
            // Search for the sublist and return the index
            for (int listIndex = start; listIndex < this.Count - sublist.Count + 1; listIndex++)
            {
                int count = 0;
                while (count < sublist.Count && sublist[count].Equals(this[listIndex + count]))
                    count++;
                if (count == sublist.Count)
                    return listIndex;
            }

            // If the sublist wasn't found we need to add each item to our list
            foreach (T item in sublist) Add(item);

            // Now let's search our list again for the new index
            for (int listIndex = start; listIndex < this.Count - sublist.Count + 1; listIndex++)
            {
                int count = 0;
                while (count < sublist.Count && sublist[count].Equals(this[listIndex + count]))
                    count++;
                if (count == sublist.Count)
                    return listIndex;
            }

            // No match was found, so an error has occured
            return -1;
        }
    }
}
