﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace XuiWorkshop
{
    public partial class FormRecursive : DockContent
    {
        private string folderPath;

        public FormRecursive(string rFolderPath)
        {
            folderPath = rFolderPath;

            InitializeComponent();
            this.ShowHint = DockState.Document;
        }

        public void RecursiveDump()
        {
            string[] xurFiles = Directory.GetFiles(folderPath, "*.xur");

            if (!Directory.Exists(folderPath + "//Xui"))
                Directory.CreateDirectory(folderPath + "//Xui");

            // Clear Log
            dumpLog.Clear();

            PROCESS_FLAGS processFlags = new PROCESS_FLAGS();
            processFlags.useXam = Form1.Instance.xamClassesToolStripMenuItem.Checked;
            processFlags.xuiToolVersion = Form1.Instance.xuiToolVersionToolStripMenuItem.Checked;
            processFlags.useAnimations = Form1.Instance.addAnimationsToolStripMenuItem.Checked;

            foreach (string path in xurFiles)
            {
                string filename = Path.GetFileNameWithoutExtension(path);

                // Open our file
                FileStream fileReader = new FileStream(path, FileMode.Open);
                XurReader reader = new XurReader(fileReader);

                XUIOBJECTDATA baseObject = reader.LoadObjectsFromBinary();
                fileReader.Close();

                // Make sure we recived a valid object
                if (baseObject != null)
                {
                    XuiWriter xuiWrite = new XuiWriter();
                    xuiWrite.BuildXui(folderPath + "//Xui//" + filename + ".xui", baseObject, processFlags);
                    dumpLog.AppendText("Success........" + filename + "\n");
                    Log.Instance.completedScenes.Add(filename);

                    // Build Ext File
                    processFlags.extFile = true;

                    string extFileName = filename + "_EXT.xui";

                    xuiWrite.BuildXui(folderPath + "//Xui//" + extFileName, baseObject, processFlags);

                    processFlags.extFile = false;

                    if (Global.writeExtFile)
                    {
                        dumpLog.AppendText("    Ext........" + extFileName + "\n");
                    }
                }
                else
                {
                    dumpLog.AppendText("Failed........" + filename + "\n");
                    Log.Instance.failedScenes.Add(filename);
                }
            }

            // Print our log file
            Log.Instance.PrintLog();

            MessageBox.Show("Recursive Dump Complete", "Dump Complete", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }
    }
}
