# AuroraAssetEditor
A Graphical editor for Aurora's .asset files

There will be more features added to this tool as i find the time to do so, first version only supports reading/writing Aurora .asset files

A Huge thanks goes out to MaesterRowen for explaining the format for me, and also for making the AuroraAsset.dll library which handles the image conversion (between D3DTexture and Bitmap)
Many thanks also goes to Mattie for the placeholder images :)

Thanks also goes to gavin_darkglider & felida for helping me test this thing :)

Thanks to RAP7HOR for the icon used in the application as of version 1.1!