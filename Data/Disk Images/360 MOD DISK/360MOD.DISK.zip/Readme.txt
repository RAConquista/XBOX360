360 Modification Disc v1.5 Revision 2 by FrostyTheSnowman       
---------------------------------------------------------



Changes:

 - Improved dumping/flashing speeds for BenQ/Samsung drives
 - Added 'user firmware dump verification' prompt to prevent possible BenQ bricking
 - Revised menus and more detailed drive flashing/dumping instructions

Features:

 - Complete Modding Solution for Samsung/BenQ/Lite-On
 - iXtreme v1.5 (12x) Firmware
 - Supports Samsung TS-H943
 - Supports BenQ VAD6038
 - Supports Lite-On DG-16D2S
 - Supports Previously Modded Drives
 - Supports Previously Spoofed Drives
 - 100% DOS Based Dumping & Flashing
 - Supports FAT32 & NTFS Filesystems (WinXP/Vista 32-Bit & 64-Bit)
 - Fully Automatic Dumping & Flashing
 - Step-by-Step Instructions
 - Backup of all drive-related files to HDD




NOTE: This disc requires a VIA VT6421 PCI SATA (or compatible) card 
      installed, and an NTFS or FAT32 formatted HDD/partition as the 
      'C:' drive for this disc to work properly.

NOTE 2: This disc *might* work with other types of SATA chipsets/cards,
        but it is recommended that you use a VIA VT6421 SATA card.

NOTE 3: USB serial adapters are NOT compatible with this disc!




Usage:

 - Make sure you have a VT6421 (or compatible) PCI SATA card installed in your PC

 - Burn this ISO, and boot this disc in your PC

 - Follow the prompts to mod any Samsung, BenQ, or Lite-On XBOX 360 DVD-ROM drive

 - All firmware dumps, modified firmware, and other files related to the drive being 
   modified will be placed in the following directories on your 'C' drive:

	Samsung TS-H943 - C:\SAMFILES

	BenQ VAD6038 - C:\BENFILES

	Lite-On DG-16D2S - C:\LONFILES




Disclaimer:

I take absolutely no responsibilty for the use of this disc by anyone. Use at your own risk!




Special Thanks & Credits:

Team Jungle - For the awesome iXtreme v1.5 firmware used by this disc
Datapol-Technologies - For their shareware NTFS4DOS software (NTFS support)
Dennis Bareis - GETRESP (used to input variables into MS-DOS batch files)
Franck Uberto - XMSDSK (used to create a RAMDISK under MS-DOS)
Geremia, Modfreakz, Podger, Redline99 and Tiros - DOSFLASH (BenQ/Lite-On)
Joseph Lin - MTKFLASH (Samsung)
Caster420 - Firmtool (Samsung/BenQ/Lite-On iXtreme firmware generating)
TJ - DVDKey & DummyGen (used to dump firmware for the Lite-On drive)
yaywoop - Original design of the included (and slightly modified) serial diagram

