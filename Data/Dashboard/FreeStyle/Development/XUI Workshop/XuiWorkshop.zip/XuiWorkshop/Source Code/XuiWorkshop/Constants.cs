﻿//*************************************************************
//  Filename:       Constants.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Static class containing constants.
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XuiWorkshop
{
    static class Constants
    {
        // XUI\XURv8 Constants
        public struct Xur8
        {
            public const uint Magic = 0x58554942;
            public const uint Version = 0x00000008;
            public const ushort XuiVersion = 0x000E;
        }

        // XUI\XURv5 Constants
        public struct Xur5
        {
            public const uint Magic = 0x58554942;
            public const uint Version = 0x00000005;
            public const ushort XuiVersion = 0x000C;
        }

        public struct XurSection
        {
            public const uint DBUG = 0x44425547;
            public const uint STRN = 0x5354524E;
            public const uint VECT = 0x56454354;
            public const uint QUAT = 0x51554154;
            public const uint CUST = 0x43555354;
            public const uint FLOT = 0x464C4F54;
            public const uint COLR = 0x434F4C52;
            public const uint KEYP = 0x4B455950;
            public const uint KEYD = 0x4B455944;
            public const uint NAME = 0x4E414D45;
            public const uint DATA = 0x44415441;
            //public const uint[] Sections = { DBUG, STRN, VECT, QUAT, CUST, FLOT, COLR, KEYP, KEYD, NAME, DATA };
        }
    }
}
