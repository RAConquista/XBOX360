﻿//*************************************************************
//  Filename:       XuiInjectExt.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Class used to inject EXT files into XUI heirarchy.
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XuiWorkshop
{
    class XuiInjectExt
    {
        public XUIOBJECTDATA InjectExt(XUIOBJECTDATA xuiInjectObjects, XUIOBJECTDATA baseObject)
        {
            List<XUIOBJECTDATA> injectList = xuiInjectObjects.ChildrenArray.FindAll(x => x.PropertyArray.Count > 1 || x.SubTimelines.Exists(y => y.PropPathArray.Count > 0));

            foreach (XUIOBJECTDATA obj in injectList)
            {
                XUIOBJECTDATA objectToUpdate = baseObject.ChildrenArray.Find(x => x.GetPropVal("Id").ToString() == obj.GetPropVal("Id").ToString());

                // Matching Child not found something went wrong
                if (objectToUpdate == null)
                    return null;

                // Inject new properties 
                for (int i = 1; i < obj.PropertyArray.Count; i++)
                    objectToUpdate.PropertyArray.Add(obj.PropertyArray[i]);


                // Inject timeline
                if (obj.SubTimelines.Count > 0)
                {
                    // If object has no timlines inject the entire block
                    if (objectToUpdate.SubTimelines.Count == 0)
                    {
                        // Add timelines
                        foreach (XUISUBTIMELINEDATA subTimeline in obj.SubTimelines)
                            objectToUpdate.SubTimelines.Add(subTimeline);
                    }
                    else // Timeline exists so now were going to have to check each subtimeline and inject manually
                    {
                        foreach (XUISUBTIMELINEDATA subTimeline in objectToUpdate.SubTimelines)
                        {
                            foreach (XUISUBTIMELINEDATA injectTimeline in obj.SubTimelines)
                            {
                                if (subTimeline.ElementId == injectTimeline.ElementId)
                                {
                                    foreach (XUITIMELINEPROPPATH injectProp in injectTimeline.PropPathArray)
                                    {
                                        // Add to propPath Array
                                        subTimeline.PropPathArray.Add(injectProp);

                                        // Add to numPropPath
                                        subTimeline.NumPropPaths++;

                                        // Add to index array
                                        subTimeline.IndexArray.Add(injectProp.Index);

                                    }

                                    // Update Keyframes with new prop
                                    for (int m = 0; m < subTimeline.KeyframeDataArray.Count; m++)
                                    {
                                        // Add Keyframe Props
                                        foreach (XUIPROPERTYDATA injectKeyframeProp in injectTimeline.KeyframeDataArray[m].PropList)
                                        {
                                            subTimeline.KeyframeDataArray[m].PropList.Add(injectKeyframeProp);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (baseObject.ChildrenArray.Count > 0 && xuiInjectObjects.ChildrenArray.Count > 0)
            {
                for (int j = 0; j < baseObject.ChildrenArray.Count; j++)
                {
                    // Find next injection object. If temp is null there is no matching ext object 
                    XUIOBJECTDATA temp = new XUIOBJECTDATA();
                    if (j < xuiInjectObjects.ChildrenArray.Count)
                        temp = xuiInjectObjects.ChildrenArray.Find(x => x.GetPropVal("Id").ToString() == baseObject.ChildrenArray[j].GetPropVal("Id").ToString());

                    if (temp != null)
                        InjectExt(temp, baseObject.ChildrenArray[j]);
                    else
                        Console.WriteLine("Object - " + baseObject.ChildrenArray[j].GetPropVal("Id") + " not found in EXT file must be new");
                }
            }


            return baseObject;
        }
    }
}
