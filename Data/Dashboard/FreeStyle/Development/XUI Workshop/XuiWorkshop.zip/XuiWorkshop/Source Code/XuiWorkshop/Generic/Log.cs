﻿//*************************************************************
//  Filename:       Log.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Class to help with error logging.
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace XuiWorkshop
{
    public sealed class Log
    {
        // Singleton
        static readonly Log instance = new Log();

        static Log() { }

        public static Log Instance
        {
            get
            {
                return instance;
            }
        }

        public List<string> missingClasses;
        public List<uint> flagErrors;
        public List<string> failedScenes;
        public List<string> completedScenes;
        public List<string> sharedresImages;
        public List<string> xamImages;
        public List<string> skinImages;
        public List<string> hudImages;
        public List<string> customImages;
        StreamWriter fileWriter;

        Log()
        {
            missingClasses = new List<string>();
            flagErrors = new List<uint>();
            failedScenes = new List<string>();
            completedScenes = new List<string>();
            sharedresImages = new List<string>();
            xamImages = new List<string>();
            skinImages = new List<string>();
            hudImages = new List<string>();
            customImages = new List<string>();
        }

        public void PrintLog()
        {
            fileWriter = new StreamWriter(Application.StartupPath + "//Log.txt");

            fileWriter.WriteLine(System.DateTime.Now);
            fileWriter.WriteLine("========================================================");
            fileWriter.WriteLine("Completed Scenes");
            fileWriter.WriteLine("-----------------------------------------");
            foreach (string s in completedScenes)
                fileWriter.WriteLine("- " + s);
            fileWriter.WriteLine();

            if (failedScenes.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Failed Scenes");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in failedScenes)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (missingClasses.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Missing Classes");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in missingClasses)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (flagErrors.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Flag Errors");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (int i in flagErrors)
                    fileWriter.WriteLine("- " + i.ToString());
                fileWriter.WriteLine();
            }

            if (sharedresImages.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Sharedres Images");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in sharedresImages)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (xamImages.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Xam Images");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in xamImages)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (skinImages.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Skin Images");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in skinImages)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (customImages.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Custom Images");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in customImages)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            if (hudImages.Count > 0)
            {
                fileWriter.WriteLine("-----------------------------------------");
                fileWriter.WriteLine("Hud Images");
                fileWriter.WriteLine("-----------------------------------------");
                foreach (string s in hudImages)
                    fileWriter.WriteLine("- " + s);
                fileWriter.WriteLine();
            }

            fileWriter.WriteLine("========================================================");
            fileWriter.WriteLine();
            fileWriter.WriteLine();

            fileWriter.Flush();
            fileWriter.Close();
        }
    }
}
