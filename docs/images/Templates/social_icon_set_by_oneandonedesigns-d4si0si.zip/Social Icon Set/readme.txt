****************************************************************************

		     	      Social Icon Set

	  	      Designed By - One & One Designs

This Social Icon Set, is completely free for your personal/commercial projects. You can use this free resource in any way that suits you, whether it�s your web project or any print material for sale or distribution. We wouldn�t restrict you. No backlinks or attributions are required but if you spread the word, then we will highly appreciate you. We request you to take the following things in mind that don�t credit yourself for our work & don�t distribute the following resource anywhere else, without our prior permission. 

Downloaded from: http://oneandonedesigns.deviantart.com/

Regards,
One & One Designs

****************************************************************************