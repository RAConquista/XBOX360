---------------------------------------------------------------------
Maximus - FIRMWARE TOOLBOX V4.8
---------------------------------------------------------------------
Last minute change, thanks to DeViLs360 for pointing possible issue 
with spoofing drives to liteon

WHATS NEW ON V4.8:

   - ADDED:     Custom Spoofing Option on "Tools->Spoof Firmware" option
                (it asks for your 96 bytes inquiry.bin), this could be 
                safer for spoofing drives to Liteon because appears 
                Liteon drives have per-drive specific inquiry response.

		If you lost you inquiry.bin file and cannot redump it, then 
                go ahead with listed Liteon spoofing option (it will work 
                but you will not have the factory value).

   - ADDED:     You can now open key.bin file from main window instead of
                manually type the key (will ask for a 16 bytes file).

   - FIXED:     Clicking on firmware file didnt open properly on toolbox.

WHATS WAS NEW ON YESTERDAY V4.7:

   - ADDED:     Spoofing drives to Liteon DG model
   - ADDED:     Detect/Remove Hardware (DVD-ROM) (on File Menu)
   - ADDED:     Ixtreme 1.4 No-Check Bit firmware for 79 Drives
   - FIXED:     Several bugs.

Note: The No-check bit option for 79 drives is not set as default firmware
on Smart hack patcher option, you need to choose it from the list on the
Special Firmwares section, the reason is it could be unsafe and lead to M$
detection. 

Congrats to geremia, c4e and all others for the latest Liteon releases


WHAT IS IT ?
---------- 
   A graphical tool to handle several common dvd-drive firmware
   tasks. This is the better tool you will find.
 
   You can copy-paste the keys from one firmware to another not 
   matter if they are different vendor (samsung / hitachi / BENQ)
   and not matter the version of the FW

   Allows SMART PATCH for rolling code firmwares (Hitachi 0078/0079) and
   also Direct Flash on all drives, even the nasty 78/79 drives.

   RAWDUMP does not work fine with SIL chipsets yet, be aware of use 
   the validate checksum feature to avoid bad dumps and bricks. We
   will be working on SIL chipsets later.

   The flasher/restore appears to be rock solid now, also very easy
   to understand, so this could be the base to flash future firmware 
   releases, even on the 78


FEATURES:
---------
 - Direct Dump and Direct Flash over all versions of GDR3120L drives
   even the 0078 FK drives. For 79 FK you will need aditional device
   attached to the drive.
 - Allow copy-paste of the keys between firmare not matter if
   they are crypted or not or if they are different vendor or
   even better, not matter which version of Fw (46,47,59,78 etc)
 - Do common firmware tasks with a mouse click
 - Supports Samsung and Hitachi firmwares All Versions 
 - Shows Vendor, ROM version and also if its CRYPTED or NOT
 - Allow crypt or decrypt the files
 - Shows the 16 byte Keys not matter if the file is Crypted
 - Allows adding of TAGS to a KEY like Owner, Serial No, Date.
   (Dont worry, the tags are not saved onto firmware file)
 - Fully Integrated with Windows Context Menu (like winrar)
 - Fully Supports 512 KB firmwares (2 banks)


SPONSORSHIP DONATION:
---------------------
   N/A, if you like to support our research go to 

   http://www.maximusgames.net/79passkeyinfo.php

   and purchase our hardware



INSTALLATION:
---------------
 - Unzip contents on the folder you like
 - Open application and go to Options->Enable Windows Context Menu
 - Close application



HOW TO USE:
------------------
 - READ THE ATTACHED FILE LABELED TUTORIALS.TXT

 - To open a file you can just on Windows Explorer do Right Click and
   choose "Open with Firmware Toolbox", or you can first launch the 
   application and do File-Open menu or simply drag a file from your
   browser to the application.

 - To encrypt or decrypt a file just open it as above and click the
   button encrypt or decrypt.

 - To replace a key just type it or copy-paste it into the key
   textbox and click on "Replace Key"

 - To set or replace Tag Data just type it into the Tag Data Section
   "Save Tag Data".  This Tag Data will be show every time you open
   a file that have the same key.  Useful to identify an Owner's Key



CHANGE LOG
---------- 
WHATS NEW ON V4.70:

   - ADDED:     i-xtreme 1.4 multispeed for all Hitachi Versions (Credit is to C4E)
   - FIXED: 	Properly Display BENQ VAD6038 Hacker String located at 5FE0
   - FIXED:     Several bugs.

WHATS NEW ON V4.50:

   - FIXED: 	Properly support Handling of VAD6038 Firmwares (see notes).
   - FIXED:     Previously Hitachi spoofed drives were not visible on toolbox anymore
                now you can see it and unspoof it or re-spoof them
   - FIXED:     Several other bugs

V4.00:
WHATS NEW ON V4.00:

   - Added: 	Smart Hack Patcher now implements ixtreme 1.2 (thanks to c4e)
   - Added:     Now Supports 100% BENQ Firmwares (spoof, key changing, etc)
   - Added:     Option to Restore Original Firmwares based on any dump you have
   - Corrected: Several other bugs
   - Added:     OCX's included on the release
                (there are available on Microsoft site anyway)


v3.1:
WHATS NEW ON V3.1b:

   - Added: 	Hitachi Xtreme 1.7 (Disc Jitter Fix by "c4eva")
   - Added: 	Smart Hack Patcher now works for all Production Drives
                V40 thru v79
   - Added:     Correctly show and handle of keys for Hit79 drives
   - Corrected: Bug displaying Samsung FW as spoofed (display error)
   - Corrected: Several other bugs
   - Improved : Checksum checkup when dumping

   - Added:     OCX's included on the release
                (REPACK, first v3.1b had corrupted archive)
                (there are available on Microsoft site anyway)
V3.0: 
WHATS NEW ON V3.0:

   - Added: 	Direct Dumping of GDR3120L drives attached to PC.
                Also features a new RAW memdump which is not fooled
                by the stealth method on currently hacked drives.
                Even can dump the nasty 78 drives all by software.

   - Added: 	Direct Flashing of Keys, Spoof data and also
                Direct flash of hacked firmwares over all hitachi
                drive models attached to the PC. Even flash the 
                0078FK drives and newer (I hope). So forgot epoxy
                removal for now.
                see video tutorial here: http://www.youtube.com/watch?v=KSSPmAAtMUk

   - Added: 	Option to do a Smart hack on those "Rolling 
                Code" Firmwares like 78 and surely newer ones

   - Added: 	Option to create multibank fw
   - Added: 	Option to split multibank fw
   - Added: 	Option to Spoof a firmware, you can spoof
                a Hitachi XX version to a Hitachi YY version,
                you can even spoof a hitachi Fw to report as
                a samsung drive.
   - Added: 	Option validate checksum, this will allow 
                detect proper and bad dumps before flashing


V2.0:

   - Corrected: Lookup of keys on GDR-3120L V78 because
                they dont have same location on all drives.

   - Added:     Show of the "hacker string" that identifies 
                hacked versions. (Samsung on FFE0, Hitachi 
                on 37F0) In case of 512 KB roms will only
                show for bank 0

   - Added:     Option to quick view the key database

   - Added:     Bigger "Encrypt/Decrypt" button for those that 
                have not been using this save-time feature



WHAT IS NEXT ON FUTURE TOOLBOX VERSIONS ?:
------------------------------------------   
   - Smart Hack Patcher configurable by script (avoid hard coded rules)
   - Restore and Patch Wizards (for totally noobs)



KNOWN ISSUES:
--------------
If the context menu is not shown when you right-click over a file just
open the application and do Options-Disable Windows Menu and then
Options-Enable Windows Context Menu.  Also RAWDUMP does not work
fine with SIL chipsets, be aware of use the validate checksum feature
to avoid bad dumps and bricks

Some USB 2 SATA Adapters hangs at the moment of dumping, use a 
Native Sata PC


BUGS, COMMENTS OR ADD FEATURES REQUEST:
---------------------------------------
carranzafp@hotmail.com



THANKS TO
-------------------------------------------------------------------
C4E, Seventhson, garyopa, geremia, birdy, Loser, modfreakz, uberfry, 
Tecno Devices and all others on xboxhacker.net
