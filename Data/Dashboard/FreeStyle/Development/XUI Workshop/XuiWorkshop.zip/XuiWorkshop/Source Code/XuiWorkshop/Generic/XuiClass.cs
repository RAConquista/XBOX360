﻿//*************************************************************
//  Filename:       XuiClass.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Helper class for managing and build XUI files.
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Windows.Forms;

namespace XuiWorkshop
{
    public sealed class XuiClass
    {
        // Singleton
        static readonly XuiClass instance = new XuiClass();

        static XuiClass() { }

        XuiClass() { }

        public static XuiClass Instance
        {
            get
            {
                return instance;
            }
        }

        // Singleton copy of ExtensionClassList
        private List<XUI_CLASS> loc_extensionClassList;

        public void BuildClass(List<string> xmlExtensionsList)
        {
            loc_extensionClassList = new List<XUI_CLASS>();

            UpdateClassList(xmlExtensionsList);
        }

        public XUI_CLASS FindClass(string className)
        {
            foreach (XUI_CLASS tmpClass in loc_extensionClassList)
            {
                if (tmpClass.szClassName == className)
                    return tmpClass;
            }

            // return empty object
            return default(XUI_CLASS);
        }

        public XUIELEM_PROP_DEF FindProperty(string Id, string mostDerrivedClass)
        {
            List<IList> temp = new List<IList>();
            temp = GetHierarchy(mostDerrivedClass);
            if (temp != null)
            {
                foreach (List<XUIELEM_PROP_DEF> baseList in temp)
                {
                    foreach (XUIELEM_PROP_DEF tmpProp in baseList)
                    {
                        if (tmpProp.PropName == Id)
                            return tmpProp;
                    }
                }
            }

            return default(XUIELEM_PROP_DEF);
        }

        public XUIELEM_PROP_DEF FindFigureProperty(string Id, string figureType)
        {
            List<XUIELEM_PROP_DEF> tmpClass;
            if (figureType == "Stroke")
                tmpClass = GetStrokePropArray();
            else if (figureType == "Fill")
                tmpClass = GetFillPropArray();
            else
                tmpClass = GetGradientPropArray();

            foreach (XUIELEM_PROP_DEF tmpProp in tmpClass)
            {
                if (tmpProp.PropName == Id)
                    return tmpProp;
            }

            return default(XUIELEM_PROP_DEF);
        }

        public void UpdateClassList(List<string> xmlExtensionsList)
        {
            // Empty List
            loc_extensionClassList.Clear();

            XmlExtensionParse parseXml = new XmlExtensionParse();
            List<XUI_CLASS> tempArray = new List<XUI_CLASS>();
            foreach (string path in xmlExtensionsList)
            {
                // Get Array of classes
                tempArray = parseXml.readExtension(path);

                // Add each class item to extension class array
                foreach(XUI_CLASS tempClass in tempArray)
                    loc_extensionClassList.Add(tempClass);
            }
        }

        // Returns a list of PropDef Arrays based on the hierarchy of the given class
        //  index 0 is root
        public List<IList> GetHierarchy(string mostDerrivedClass)
        {
            List<IList> hierarchy = new List<IList>();
            XUI_CLASS temp = FindClass(mostDerrivedClass);

            // Class Missing break out
            if (temp.szClassName == null)
            {
                if(Array.IndexOf(Log.Instance.missingClasses.ToArray(), mostDerrivedClass) == -1)
                    Log.Instance.missingClasses.Add(mostDerrivedClass);
                return null;
            }

            hierarchy.Add(temp.PropDefs);

            // Max level i've seen is 3 but 5 is just to be safe
            for (int i = 0; i < 5; i++)
            {
                if (temp.szBaseClassName != "(null)")
                {
                    temp = FindClass(temp.szBaseClassName);
                    hierarchy.Add(temp.PropDefs);
                }
            }

            // Reverse order so we start with Root class props
            hierarchy.Reverse();

            return hierarchy;
        }

        public List<XUIELEM_PROP_DEF> GetFillPropArray()
        {
            XUI_CLASS temp = FindClass("XuiFigureFill");

            return temp.PropDefs;
        }

        public List<XUIELEM_PROP_DEF> GetGradientPropArray()
        {
            XUI_CLASS temp = FindClass("XuiFigureFillGradient");

            return temp.PropDefs;
        }

        public List<XUIELEM_PROP_DEF> GetStrokePropArray()
        {
            XUI_CLASS temp = FindClass("XuiFigureStroke");

            return temp.PropDefs;
        }

        public List<XUIELEM_PROP_DEF> GetIgnoredPropArray()
        {
            XUI_CLASS temp = FindClass("IgnoredProps");

            return temp.PropDefs;
        }

        // Debug Method for outputing properties with a given type
        public void ShowObjectType(XUIELEM_PROP_TYPE type)
        {
            foreach (XUI_CLASS tmpClass in loc_extensionClassList)
            {
                foreach (XUIELEM_PROP_DEF tmpProp in tmpClass.PropDefs)
                {
                    if (tmpProp.Type == type)
                        Console.WriteLine(tmpClass.szClassName + " - " + tmpProp.PropName);
                }
            }
        }

        // Accessor Methods to XUI_CLASS list
        public List<XUI_CLASS> extensionClassList
        {
            get { return loc_extensionClassList; }
        }
    }
}
