This xex will start Xell from an actively running machine.

Place xell at one of the following locations:
	root of USB memory stick
	root of HDD content partition
	root of CD/DVD ROM
	Beside the xelllaunch xex
The file can be named one of the following:
	xell.bin (xell-1f.bin renamed to xell.bin)
	xell-1f.bin
	xell-2f.bin

If not found in one of these locations, it will attempt to
	load xell from flash (xell-1f on glitch machines, xell-2f on jtag.)
	Note that glitch xell from flash probably won't load.
