﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace XuiWorkshop
{
    public partial class XmlExtensions : Form
    {
        private List<string> loc_xmlExtensionList;

        public XmlExtensions()
        {
            InitializeComponent();

            xmlExtensionList = new List<string>();
        }

        // Fill our list on form load
        private void XmlExtensions_Load(object sender, EventArgs e)
        {
            // Empty List
            listExtensions.Items.Clear();

            // Fill our list with existing list data
            foreach (string obj in loc_xmlExtensionList)
            {
                // Only fill list with file names
                string fileName = Path.GetFileName(obj);
                listExtensions.Items.Add(fileName);
            }

            // Disable remove button
            btnRemove.Enabled = false;
        }


        // Controls
        private void btnAdd_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog and get result.
            if (result == DialogResult.OK)
            {
                foreach (string file in openFileDialog1.FileNames)
                {
                    string fileName = Path.GetFileName(file);

                    // Add to list
                    listExtensions.Items.Add(fileName);

                    // Add path to Array List
                    loc_xmlExtensionList.Add(file);
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            // Offset variable to update index after items are removed
            int move = 0;
            foreach (object obj in listExtensions.SelectedItems)
            {
                int index = listExtensions.Items.IndexOf(obj);

                loc_xmlExtensionList.RemoveAt(index - move);
                move++;
            }

            // Items removed rebuild list
            listExtensions.Items.Clear();
            foreach (string file in loc_xmlExtensionList)
            {
                string fileName = Path.GetFileName(file);

                // Add to list
                listExtensions.Items.Add(fileName);
            }
        }

        private void listExtensions_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Item Selected
            if (listExtensions.SelectedIndex >= 0)
                btnRemove.Enabled = true;
        }


        // Accessor Methods to XML Property list
        public List<string> xmlExtensionList
        {
            get { return loc_xmlExtensionList; }
            set { loc_xmlExtensionList = value; }
        }
    }
}
