﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;
using System.IO;
using System.Diagnostics;

namespace XuiWorkshop
{
    public partial class FormXur : DockContent
    {
        private string filePath;

        public FormXur(string rFilePath)
        {
            filePath = rFilePath;

            InitializeComponent();

            Form1.Instance.xurInfoToolStripMenuItem.Checked = true;

            // Fill out our Xur file info
            FillXurInfo();
        }

        private void FormXur_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1.Instance.xurInfoToolStripMenuItem.Checked = false;

            // Stop the form close
            e.Cancel = true;

            this.Hide();
        }

        private void FillXurInfo()
        {
            FileStream fileReader = new FileStream(filePath, FileMode.Open);
            XurReader reader = new XurReader(fileReader);

            XUR8_HEADER header = reader.GetHeaderData();
            XUR8_HEADER_INFO headerInf = reader.GetHeaderInfoData();

            reader.Close();

            headerMagic.Text = header.Magic.ToString();
            headerSectors.Text = header.NumSections.ToString();
            headerSize.Text = header.BinSize.ToString();
            headerVersion.Text = header.Version.ToString();
            headerXuiVersion.Text = header.XuiVersion.ToString();
            headerInfKeyframes.Text = headerInf.KeyframeDataCount.ToString();
            headerInfObjects.Text = headerInf.ObjectCount.ToString();
            headerInfProps.Text = headerInf.PropertyCount.ToString();
            headerInfTimelines.Text = headerInf.TimelinePropPathCount.ToString();
            headerInfContainwChil.Text = headerInf.ObjectsWithChildrenCount.ToString();
            headerInfCmpProp.Text = headerInf.CompoundObjectPropCount.ToString();
        }
    }
}
