﻿//*************************************************************
//  Filename:       FormProperties.Designer.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Form code for FormProperties.
//*************************************************************
namespace XuiWorkshop
{
    partial class FormProperties
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listProperties = new System.Windows.Forms.ListBox();
            this.propertiesVector = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.vectorZ = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.vectorY = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.vectorX = new System.Windows.Forms.TextBox();
            this.propertiesQuan = new System.Windows.Forms.GroupBox();
            this.label19 = new System.Windows.Forms.Label();
            this.quanW = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.quanZ = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.quanY = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.quanX = new System.Windows.Forms.TextBox();
            this.propertiesColor = new System.Windows.Forms.GroupBox();
            this.colorPreview = new System.Windows.Forms.PictureBox();
            this.propertiesString = new System.Windows.Forms.GroupBox();
            this.stringText = new System.Windows.Forms.TextBox();
            this.saveProperties = new System.Windows.Forms.Button();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.propertiesVector.SuspendLayout();
            this.propertiesQuan.SuspendLayout();
            this.propertiesColor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.colorPreview)).BeginInit();
            this.propertiesString.SuspendLayout();
            this.SuspendLayout();
            // 
            // listProperties
            // 
            this.listProperties.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listProperties.FormattingEnabled = true;
            this.listProperties.ItemHeight = 16;
            this.listProperties.Location = new System.Drawing.Point(12, 12);
            this.listProperties.Name = "listProperties";
            this.listProperties.Size = new System.Drawing.Size(335, 212);
            this.listProperties.TabIndex = 1;
            this.listProperties.SelectedIndexChanged += new System.EventHandler(this.listProperties_SelectedIndexChanged);
            // 
            // propertiesVector
            // 
            this.propertiesVector.Controls.Add(this.label15);
            this.propertiesVector.Controls.Add(this.vectorZ);
            this.propertiesVector.Controls.Add(this.label14);
            this.propertiesVector.Controls.Add(this.vectorY);
            this.propertiesVector.Controls.Add(this.label13);
            this.propertiesVector.Controls.Add(this.vectorX);
            this.propertiesVector.Location = new System.Drawing.Point(12, 416);
            this.propertiesVector.Name = "propertiesVector";
            this.propertiesVector.Size = new System.Drawing.Size(335, 56);
            this.propertiesVector.TabIndex = 27;
            this.propertiesVector.TabStop = false;
            this.propertiesVector.Text = "Vector";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(249, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "Z";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // vectorZ
            // 
            this.vectorZ.Location = new System.Drawing.Point(269, 26);
            this.vectorZ.Name = "vectorZ";
            this.vectorZ.Size = new System.Drawing.Size(47, 20);
            this.vectorZ.TabIndex = 29;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(132, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "Y";
            this.label14.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // vectorY
            // 
            this.vectorY.Location = new System.Drawing.Point(152, 26);
            this.vectorY.Name = "vectorY";
            this.vectorY.Size = new System.Drawing.Size(47, 20);
            this.vectorY.TabIndex = 27;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "X";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // vectorX
            // 
            this.vectorX.Location = new System.Drawing.Point(34, 26);
            this.vectorX.Name = "vectorX";
            this.vectorX.Size = new System.Drawing.Size(47, 20);
            this.vectorX.TabIndex = 25;
            // 
            // propertiesQuan
            // 
            this.propertiesQuan.Controls.Add(this.label19);
            this.propertiesQuan.Controls.Add(this.quanW);
            this.propertiesQuan.Controls.Add(this.label16);
            this.propertiesQuan.Controls.Add(this.quanZ);
            this.propertiesQuan.Controls.Add(this.label17);
            this.propertiesQuan.Controls.Add(this.quanY);
            this.propertiesQuan.Controls.Add(this.label18);
            this.propertiesQuan.Controls.Add(this.quanX);
            this.propertiesQuan.Location = new System.Drawing.Point(12, 354);
            this.propertiesQuan.Name = "propertiesQuan";
            this.propertiesQuan.Size = new System.Drawing.Size(335, 56);
            this.propertiesQuan.TabIndex = 32;
            this.propertiesQuan.TabStop = false;
            this.propertiesQuan.Text = "Quan";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(248, 29);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(18, 13);
            this.label19.TabIndex = 32;
            this.label19.Text = "W";
            this.label19.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // quanW
            // 
            this.quanW.Location = new System.Drawing.Point(268, 26);
            this.quanW.Name = "quanW";
            this.quanW.Size = new System.Drawing.Size(47, 20);
            this.quanW.TabIndex = 31;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(169, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 13);
            this.label16.TabIndex = 30;
            this.label16.Text = "Z";
            this.label16.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // quanZ
            // 
            this.quanZ.Location = new System.Drawing.Point(189, 26);
            this.quanZ.Name = "quanZ";
            this.quanZ.Size = new System.Drawing.Size(47, 20);
            this.quanZ.TabIndex = 29;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(90, 29);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 13);
            this.label17.TabIndex = 28;
            this.label17.Text = "Y";
            this.label17.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // quanY
            // 
            this.quanY.Location = new System.Drawing.Point(110, 26);
            this.quanY.Name = "quanY";
            this.quanY.Size = new System.Drawing.Size(47, 20);
            this.quanY.TabIndex = 27;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(14, 29);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 13);
            this.label18.TabIndex = 26;
            this.label18.Text = "X";
            this.label18.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // quanX
            // 
            this.quanX.Location = new System.Drawing.Point(34, 26);
            this.quanX.Name = "quanX";
            this.quanX.Size = new System.Drawing.Size(47, 20);
            this.quanX.TabIndex = 25;
            // 
            // propertiesColor
            // 
            this.propertiesColor.Controls.Add(this.colorPreview);
            this.propertiesColor.Location = new System.Drawing.Point(12, 292);
            this.propertiesColor.Name = "propertiesColor";
            this.propertiesColor.Size = new System.Drawing.Size(335, 56);
            this.propertiesColor.TabIndex = 33;
            this.propertiesColor.TabStop = false;
            this.propertiesColor.Text = "Color";
            // 
            // colorPreview
            // 
            this.colorPreview.Location = new System.Drawing.Point(34, 15);
            this.colorPreview.Name = "colorPreview";
            this.colorPreview.Size = new System.Drawing.Size(269, 34);
            this.colorPreview.TabIndex = 0;
            this.colorPreview.TabStop = false;
            this.colorPreview.Click += new System.EventHandler(this.colorPreview_Click);
            // 
            // propertiesString
            // 
            this.propertiesString.Controls.Add(this.stringText);
            this.propertiesString.Location = new System.Drawing.Point(12, 230);
            this.propertiesString.Name = "propertiesString";
            this.propertiesString.Size = new System.Drawing.Size(335, 56);
            this.propertiesString.TabIndex = 34;
            this.propertiesString.TabStop = false;
            this.propertiesString.Text = "String";
            // 
            // stringText
            // 
            this.stringText.Location = new System.Drawing.Point(34, 26);
            this.stringText.Name = "stringText";
            this.stringText.Size = new System.Drawing.Size(282, 20);
            this.stringText.TabIndex = 25;
            // 
            // saveProperties
            // 
            this.saveProperties.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.saveProperties.Location = new System.Drawing.Point(12, 484);
            this.saveProperties.Name = "saveProperties";
            this.saveProperties.Size = new System.Drawing.Size(335, 26);
            this.saveProperties.TabIndex = 35;
            this.saveProperties.Text = "Save";
            this.saveProperties.UseVisualStyleBackColor = true;
            this.saveProperties.Click += new System.EventHandler(this.saveProperties_Click);
            // 
            // colorDialog1
            // 
            this.colorDialog1.FullOpen = true;
            // 
            // FormProperties
            // 
            this.AutoHidePortion = 372D;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 517);
            this.Controls.Add(this.saveProperties);
            this.Controls.Add(this.propertiesString);
            this.Controls.Add(this.propertiesColor);
            this.Controls.Add(this.propertiesQuan);
            this.Controls.Add(this.propertiesVector);
            this.Controls.Add(this.listProperties);
            this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((WeifenLuo.WinFormsUI.Docking.DockAreas.Float | WeifenLuo.WinFormsUI.Docking.DockAreas.DockLeft) 
            | WeifenLuo.WinFormsUI.Docking.DockAreas.DockRight)));
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormProperties";
            this.ShowHint = WeifenLuo.WinFormsUI.Docking.DockState.DockRightAutoHide;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Properties";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormProperties_FormClosing);
            this.propertiesVector.ResumeLayout(false);
            this.propertiesVector.PerformLayout();
            this.propertiesQuan.ResumeLayout(false);
            this.propertiesQuan.PerformLayout();
            this.propertiesColor.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.colorPreview)).EndInit();
            this.propertiesString.ResumeLayout(false);
            this.propertiesString.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listProperties;
        private System.Windows.Forms.GroupBox propertiesVector;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox vectorZ;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox vectorY;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox vectorX;
        private System.Windows.Forms.GroupBox propertiesQuan;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox quanW;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox quanZ;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox quanY;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox quanX;
        private System.Windows.Forms.GroupBox propertiesColor;
        private System.Windows.Forms.PictureBox colorPreview;
        private System.Windows.Forms.GroupBox propertiesString;
        private System.Windows.Forms.TextBox stringText;
        private System.Windows.Forms.Button saveProperties;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}