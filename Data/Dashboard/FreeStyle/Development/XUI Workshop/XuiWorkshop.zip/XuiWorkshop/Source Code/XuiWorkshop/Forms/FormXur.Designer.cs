﻿//*************************************************************
//  Filename:       FormXur.Designer.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Form code for FormXur.
//*************************************************************
namespace XuiWorkshop
{
    partial class FormXur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.headerInfCmpProp = new System.Windows.Forms.TextBox();
            this.headerInfKeyframes = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.headerInfContainwChil = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.headerInfObjects = new System.Windows.Forms.TextBox();
            this.headerInfTimelines = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.headerInfProps = new System.Windows.Forms.TextBox();
            this.headerVersion = new System.Windows.Forms.TextBox();
            this.headerSize = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.headerSectors = new System.Windows.Forms.TextBox();
            this.headerMagic = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.headerXuiVersion = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // headerInfCmpProp
            // 
            this.headerInfCmpProp.Location = new System.Drawing.Point(301, 12);
            this.headerInfCmpProp.Name = "headerInfCmpProp";
            this.headerInfCmpProp.ReadOnly = true;
            this.headerInfCmpProp.Size = new System.Drawing.Size(100, 20);
            this.headerInfCmpProp.TabIndex = 31;
            // 
            // headerInfKeyframes
            // 
            this.headerInfKeyframes.Location = new System.Drawing.Point(820, 38);
            this.headerInfKeyframes.Name = "headerInfKeyframes";
            this.headerInfKeyframes.ReadOnly = true;
            this.headerInfKeyframes.Size = new System.Drawing.Size(100, 20);
            this.headerInfKeyframes.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(201, 15);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 13);
            this.label12.TabIndex = 30;
            this.label12.Text = "CompoundObjects";
            this.label12.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(758, 41);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Keyframes";
            this.label10.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // headerInfContainwChil
            // 
            this.headerInfContainwChil.Location = new System.Drawing.Point(301, 38);
            this.headerInfContainwChil.Name = "headerInfContainwChil";
            this.headerInfContainwChil.ReadOnly = true;
            this.headerInfContainwChil.Size = new System.Drawing.Size(100, 20);
            this.headerInfContainwChil.TabIndex = 29;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(181, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 13);
            this.label11.TabIndex = 28;
            this.label11.Text = "Containers w/ Children";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // headerInfObjects
            // 
            this.headerInfObjects.Location = new System.Drawing.Point(650, 38);
            this.headerInfObjects.Name = "headerInfObjects";
            this.headerInfObjects.ReadOnly = true;
            this.headerInfObjects.Size = new System.Drawing.Size(100, 20);
            this.headerInfObjects.TabIndex = 13;
            // 
            // headerInfTimelines
            // 
            this.headerInfTimelines.Location = new System.Drawing.Point(472, 12);
            this.headerInfTimelines.Name = "headerInfTimelines";
            this.headerInfTimelines.ReadOnly = true;
            this.headerInfTimelines.Size = new System.Drawing.Size(100, 20);
            this.headerInfTimelines.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(601, 41);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Objects";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(590, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Properties";
            this.label8.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(415, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(51, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Timelines";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // headerInfProps
            // 
            this.headerInfProps.Location = new System.Drawing.Point(650, 12);
            this.headerInfProps.Name = "headerInfProps";
            this.headerInfProps.ReadOnly = true;
            this.headerInfProps.Size = new System.Drawing.Size(100, 20);
            this.headerInfProps.TabIndex = 15;
            // 
            // headerVersion
            // 
            this.headerVersion.Location = new System.Drawing.Point(66, 38);
            this.headerVersion.Name = "headerVersion";
            this.headerVersion.ReadOnly = true;
            this.headerVersion.Size = new System.Drawing.Size(100, 20);
            this.headerVersion.TabIndex = 1;
            // 
            // headerSize
            // 
            this.headerSize.Location = new System.Drawing.Point(820, 12);
            this.headerSize.Name = "headerSize";
            this.headerSize.ReadOnly = true;
            this.headerSize.Size = new System.Drawing.Size(100, 20);
            this.headerSize.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Version";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(787, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Size";
            this.label6.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Magic";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // headerSectors
            // 
            this.headerSectors.Location = new System.Drawing.Point(472, 38);
            this.headerSectors.Name = "headerSectors";
            this.headerSectors.ReadOnly = true;
            this.headerSectors.Size = new System.Drawing.Size(100, 20);
            this.headerSectors.TabIndex = 9;
            // 
            // headerMagic
            // 
            this.headerMagic.Location = new System.Drawing.Point(66, 12);
            this.headerMagic.Name = "headerMagic";
            this.headerMagic.ReadOnly = true;
            this.headerMagic.Size = new System.Drawing.Size(100, 20);
            this.headerMagic.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(423, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Sectors";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(933, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Xui Version";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // headerXuiVersion
            // 
            this.headerXuiVersion.Location = new System.Drawing.Point(999, 12);
            this.headerXuiVersion.Name = "headerXuiVersion";
            this.headerXuiVersion.ReadOnly = true;
            this.headerXuiVersion.Size = new System.Drawing.Size(100, 20);
            this.headerXuiVersion.TabIndex = 7;
            // 
            // FormXur
            // 
            this.AutoHidePortion = 115D;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1112, 76);
            this.Controls.Add(this.headerInfCmpProp);
            this.Controls.Add(this.headerVersion);
            this.Controls.Add(this.headerInfKeyframes);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.headerSize);
            this.Controls.Add(this.headerInfContainwChil);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.headerMagic);
            this.Controls.Add(this.headerInfObjects);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.headerInfTimelines);
            this.Controls.Add(this.headerXuiVersion);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.headerSectors);
            this.Controls.Add(this.headerInfProps);
            this.Controls.Add(this.label5);
            this.DockAreas = ((WeifenLuo.WinFormsUI.Docking.DockAreas)(((WeifenLuo.WinFormsUI.Docking.DockAreas.Float | WeifenLuo.WinFormsUI.Docking.DockAreas.DockTop) 
            | WeifenLuo.WinFormsUI.Docking.DockAreas.DockBottom)));
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormXur";
            this.ShowHint = WeifenLuo.WinFormsUI.Docking.DockState.DockTop;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Xur";
            this.ResumeLayout(false);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(FormXur_FormClosing);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox headerInfCmpProp;
        private System.Windows.Forms.TextBox headerInfKeyframes;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox headerInfContainwChil;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox headerInfObjects;
        private System.Windows.Forms.TextBox headerInfTimelines;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox headerInfProps;
        private System.Windows.Forms.TextBox headerVersion;
        private System.Windows.Forms.TextBox headerSize;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox headerSectors;
        private System.Windows.Forms.TextBox headerMagic;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox headerXuiVersion;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}