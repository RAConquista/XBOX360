﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace XuiWorkshop
{
    public partial class FormProperties : DockContent
    {
        private List<XUIPROPERTYDATA> propList;

        public FormProperties()
        {
            InitializeComponent();

            saveProperties.Enabled = false;
        }

        private void FormProperties_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1.Instance.propertiesToolStripMenuItem.Checked = false;

            // Stop the form close
            e.Cancel = true;

            this.Hide();
        }

        public void UpdatePropertyList(List<XUIPROPERTYDATA> rPropList)
        {
            propList = rPropList;

            // Clear List
            listProperties.Items.Clear();

            // Empty Property Text Fields
            quanX.Text = "";
            quanW.Text = "";
            quanY.Text = "";
            quanZ.Text = "";
            stringText.Text = "";
            vectorX.Text = "";
            vectorY.Text = "";
            vectorZ.Text = "";
            colorPreview.Hide();
            propertiesString.Text = "String";

            foreach (XUIPROPERTYDATA prop in propList)
            {
                listProperties.Items.Add(prop.PropDef.PropName);
            }
        }

        private void listProperties_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listProperties.SelectedIndex >= 0)
            {
                ShowPropertyValue(propList[listProperties.SelectedIndex]);
                saveProperties.Enabled = true;
            }
        }

        private void saveProperties_Click(object sender, EventArgs e)
        {
            //SaveProperty();
        }

        private void colorPreview_Click(object sender, EventArgs e)
        {
            DialogResult result = colorDialog1.ShowDialog(); // Show the dialog and get result.
            if (result == DialogResult.OK)
            {
                colorPreview.BackColor = colorDialog1.Color;
            }
        }

        private void ShowPropertyValue(XUIPROPERTYDATA prop)
        {
            // Empty Property Text Fields
            quanX.Text = "";
            quanW.Text = "";
            quanY.Text = "";
            quanZ.Text = "";
            stringText.Text = "";
            vectorX.Text = "";
            vectorY.Text = "";
            vectorZ.Text = "";
            colorPreview.Hide();
            propertiesString.Text = "String";

            switch (prop.PropDef.Type)
            {
                case XUIELEM_PROP_TYPE.XUI_EPT_COLOR:
                    propertiesColor.Show();
                    colorPreview.BackColor = Color.FromArgb((int)prop.PropValue.ToString().ToXuiColor().argb);
                    colorPreview.Show();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_BOOL:
                    propertiesString.Show();
                    propertiesString.Text = "Bool";
                    stringText.Text = prop.PropValue.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_CUSTOM:
                    propertiesString.Show();
                    propertiesString.Text = "Custom";
                    stringText.Text = prop.PropValue.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_INTEGER:
                    propertiesString.Show();
                    propertiesString.Text = "Integer";
                    stringText.Text = prop.PropValue.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_UNSIGNED:
                    propertiesString.Show();
                    propertiesString.Text = "Unsigned";
                    stringText.Text = prop.PropValue.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_STRING:
                    propertiesString.Show();
                    propertiesString.Text = "String";
                    stringText.Text = prop.PropValue.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_FLOAT:
                    propertiesString.Show();
                    propertiesString.Text = "Float";
                    stringText.Text = String.Format("{0:0.000}", (float)prop.PropValue);
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_QUATERNION:
                    propertiesQuan.Show();
                    XUIQUATERNION quan = (XUIQUATERNION)prop.PropValue;
                    quanX.Text = quan.x.ToString();
                    quanY.Text = quan.y.ToString();
                    quanZ.Text = quan.z.ToString();
                    quanW.Text = quan.w.ToString();
                    break;
                case XUIELEM_PROP_TYPE.XUI_EPT_VECTOR:
                    propertiesVector.Show();
                    XUIVECTOR vec = (XUIVECTOR)prop.PropValue;
                    vectorX.Text = vec.x.ToString();
                    vectorY.Text = vec.y.ToString();
                    vectorZ.Text = vec.z.ToString();
                    break;
            }
        }


        //private void SaveProperty()
        //{
        //    switch (propList[listProperties.SelectedIndex].PropDef.Type)
        //    {
        //        case XUIELEM_PROP_TYPE.XUI_EPT_COLOR:
        //            XUICOLOR color = new XUICOLOR();
        //            color.argb = (uint)colorPreview.BackColor.ToArgb();
        //            propList[listProperties.SelectedIndex].PropValue = color;
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_BOOL:
        //            propList[listProperties.SelectedIndex].PropValue = Convert.ToBoolean(stringText.Text);
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_CUSTOM:
        //            XUICUSTOM cust = new XUICUSTOM();
        //            cust = propertiesString.Text.ToXuiCustom();
        //            propList[listProperties.SelectedIndex].PropValue = cust;
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_INTEGER:
        //            propList[listProperties.SelectedIndex].PropValue = Int32.Parse(stringText.Text);
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_UNSIGNED:
        //            propList[listProperties.SelectedIndex].PropValue = UInt32.Parse(stringText.Text);
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_STRING:
        //            propList[listProperties.SelectedIndex].PropValue = stringText.Text;
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_FLOAT:
        //            propList[listProperties.SelectedIndex].PropValue = float.Parse(stringText.Text);
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_QUATERNION:
        //            XUIQUATERNION quan = new XUIQUATERNION();
        //            quan.w = float.Parse(quanW.Text);
        //            quan.x = float.Parse(quanX.Text);
        //            quan.y = float.Parse(quanY.Text);
        //            quan.z = float.Parse(quanZ.Text);

        //            propList[listProperties.SelectedIndex].PropValue = quan;
        //            break;
        //        case XUIELEM_PROP_TYPE.XUI_EPT_VECTOR:
        //            XUIVECTOR vec = new XUIVECTOR();
        //            vec.x = float.Parse(vectorX.Text);
        //            vec.y = float.Parse(vectorY.Text);
        //            vec.z = float.Parse(vectorZ.Text);

        //            propList[listProperties.SelectedIndex].PropValue = vec;
        //            break;
        //    }
        //}

    }
}
