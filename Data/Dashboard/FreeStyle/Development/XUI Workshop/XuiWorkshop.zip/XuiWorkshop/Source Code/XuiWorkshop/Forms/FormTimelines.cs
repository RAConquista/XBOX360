﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WeifenLuo.WinFormsUI.Docking;

namespace XuiWorkshop
{
    public partial class FormTimelines : DockContent
    {
        List<XUISUBTIMELINEDATA> timelines;
        List<XUINAMEDFRAMEDATA> namedFrames;

        DataGridViewCell elementIdCells;
        DataGridViewCell frameCells;

        public FormTimelines()
        {
            InitializeComponent();

            // Create our Cell Format Types
            elementIdCells = new DataGridViewTextBoxCell();
            elementIdCells.Style.BackColor = Color.White;

            frameCells = new DataGridViewTextBoxCell();
            frameCells.Style.BackColor = Color.LightGray;
            frameCells.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            frameCells.Style.SelectionBackColor = Color.Black;
            frameCells.Style.SelectionForeColor = Color.White;
            Padding pad = new System.Windows.Forms.Padding(0);
            frameCells.Style.Padding = pad;
            frameCells.Style.WrapMode = DataGridViewTriState.True;
        }

        private void FormTimelines_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1.Instance.timelinesToolStripMenuItem.Checked = false;

            // Stop the form close
            e.Cancel = true;

            this.Hide();
        }

        public void CreateTimeLines(List<XUISUBTIMELINEDATA> rTimeline, List<XUINAMEDFRAMEDATA> rNamedFrames)
        {
            timelines = rTimeline;
            namedFrames = rNamedFrames;

            // Clear our data
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Clear();
            dataGridView1.Rows.Clear();

            // If we have no timeline break out
            if (timelines.Count == 0)
            {
                AddNamedFrames(0);
                return;
            }

            // Create Element Id Column
            DataGridViewColumn elementId = new DataGridViewColumn();
            elementId.Width = 150;
            elementId.CellTemplate = elementIdCells;
            elementId.Name = "elementId";
            elementId.HeaderText = "";
            dataGridView1.Columns.Add(elementId);
            
            // Find the Object with the most Keyframes
            uint maxFrame = rTimeline.Max(x => x.KeyframeDataArray.Max(y => y.Frame));

            // Use that value to create a row item
            for (int i = 0; i < maxFrame + 1; i++)
            {
                DataGridViewColumn frame = new DataGridViewColumn();
                frame.Width = 18;
                frame.CellTemplate = frameCells;
                frame.Name = "frame" + i;
                frame.HeaderText = i.ToString();
                frame.FillWeight = 1;
                frame.ToolTipText = i.ToString();
                dataGridView1.Columns.Add(frame);
            }

            // Named Frame Row
            AddNamedFrames(maxFrame);

            // Add Numberd Frames if we dont have any Named Frames
            if (namedFrames.Count == 0)
            {
                // Assign numbers to our header text
                dataGridView1.Rows.Add();
                for (int i = 1; i < maxFrame + 2; i++)
                    dataGridView1.Rows[0].Cells[i].Value = (i - 1);
            }

            // Loop through our timelines and create our rows
            int RowCount = 1;
            foreach (XUISUBTIMELINEDATA subTimeline in timelines)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[RowCount].Cells[0].Value = subTimeline.ElementId;

                // Fill in out timeline structure
                for (int j = 0; j < subTimeline.KeyframeDataArray.Count; j++)
                {
                    XUIKEYFRAMEDATA data = subTimeline.KeyframeDataArray[j];

                    dataGridView1.Rows[RowCount].Cells[(int)data.Frame + 1].Style.BackColor = Color.Gray;
                    dataGridView1.Rows[RowCount].Cells[(int)data.Frame + 1].Value = "•";
                    dataGridView1.Rows[RowCount].Cells[(int)data.Frame + 1].ToolTipText = data.Frame.ToString();

                    // Format our cells for interpolation type
                    if (j + 1 < subTimeline.KeyframeDataArray.Count)
                    {
                        for (int k = (int)data.Frame + 2; k < subTimeline.KeyframeDataArray[j + 1].Frame + 1; k++)
                        {
                            if (data.InterpolateType == XUI_INTERPOLATE.XUI_INTERPOLATE_LINEAR)
                                dataGridView1.Rows[RowCount].Cells[k].Style.BackColor = Color.LightGreen;
                            else if (data.InterpolateType == XUI_INTERPOLATE.XUI_INTERPOLATE_EASE)
                                dataGridView1.Rows[RowCount].Cells[k].Style.BackColor = Color.MediumPurple;

                            dataGridView1.Rows[RowCount].Cells[k].Value = "-----";
                            dataGridView1.Rows[RowCount].Cells[k].ToolTipText = (k - 1).ToString();
                            dataGridView1.Rows[RowCount].Cells[(int)data.Frame + 2].Value = ">---";
                            dataGridView1.Rows[RowCount].Cells[(int)subTimeline.KeyframeDataArray[j + 1].Frame].Value = "--->";

                        }
                    }
                }
                RowCount++;
            }
        }

        private void AddNamedFrames(uint frameCount)
        {
            uint maxFrame;
            
            // Check if we have any named frames
            if (namedFrames.Count == 0)
                return;   

            // We have no timelines show named frames
            if (frameCount == 0)
            {
                // Create Element Id Column
                DataGridViewColumn elementId = new DataGridViewColumn();
                elementId.Width = 150;
                elementId.CellTemplate = elementIdCells;
                elementId.Name = "elementId";
                elementId.HeaderText = "";
                dataGridView1.Columns.Add(elementId);

                // Find the Object with the most Keyframes
                maxFrame = namedFrames.Max(x => x.Time);

                // Use that value to create a row item
                for (int i = 0; i < maxFrame + 1; i++)
                {
                    DataGridViewColumn frame = new DataGridViewColumn();
                    frame.Width = 18;
                    frame.CellTemplate = frameCells;
                    frame.Name = "frame" + i;
                    frame.HeaderText = i.ToString();
                    frame.FillWeight = 1;
                    frame.ToolTipText = i.ToString();
                    dataGridView1.Columns.Add(frame);
                }
            }
            else
                maxFrame = frameCount;

            // Assign numbers to our header text
            dataGridView1.Rows.Add();
            for (int j = 1; j < maxFrame + 2; j++)
                dataGridView1.Rows[0].Cells[j].Value = (j - 1);

            // Named Frame Row
            dataGridView1.Rows[0].Cells[0].Value = "";
            foreach (XUINAMEDFRAMEDATA frame in namedFrames)
            {
                dataGridView1.Rows[0].Cells[(int)frame.Time + 1].ToolTipText = frame.Name;
                if (frame.Command == XUI_NAMEDFRAME_COMMAND.XUI_CMD_PLAY ||
                   frame.Command == XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDPLAY)
                    dataGridView1.Rows[0].Cells[(int)frame.Time + 1].Style.BackColor = Color.Green;
                else if (frame.Command == XUI_NAMEDFRAME_COMMAND.XUI_CMD_STOP ||
                         frame.Command == XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDSTOP)
                    dataGridView1.Rows[0].Cells[(int)frame.Time + 1].Style.BackColor = Color.Red;
                else if (frame.Command == XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTO)
                    dataGridView1.Rows[0].Cells[(int)frame.Time + 1].Style.BackColor = Color.Yellow;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == 0)
            {
                XUINAMEDFRAMEDATA frame = namedFrames.Find(x => x.Time == (e.ColumnIndex - 1));

                if (frame.Name != null)
                {
                    if (frame.Target == null)
                        Form1.Instance.toolStripStatusLabel1.Text = "Named Frame : " + frame.Name + "       Command: " + frame.Command.ToString(0);
                    else
                        Form1.Instance.toolStripStatusLabel1.Text = "Named Frame : " + frame.Name + "       Command: " + frame.Command.ToString(0) + "        Target: " + frame.Target;
                }
                else
                    Form1.Instance.toolStripStatusLabel1.Text = "";
            }
            else
            {
                Form1.Instance.toolStripStatusLabel1.Text = timelines[e.RowIndex - 1].ElementId + " - Frame: " + (e.ColumnIndex - 1);
                XUIKEYFRAMEDATA data = timelines[e.RowIndex - 1].KeyframeDataArray.Find(x => x.Frame == (e.ColumnIndex - 1));

                // Update our property list with keyframe properties
                if (data != null)
                    Form1.Instance.formPROPERTIES.UpdatePropertyList(data.PropList);
            }
        }
    }
}
