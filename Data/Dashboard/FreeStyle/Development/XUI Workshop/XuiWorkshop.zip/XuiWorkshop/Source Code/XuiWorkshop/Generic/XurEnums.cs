﻿//*************************************************************
//  Filename:       XuiEnums.cs
//  Author:         MaesterRowen & Wondro (TeamFSD)
//  Date:           August 10, 2013
//  Description:    Enums used in the XUI/XUR format .
//*************************************************************

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace XuiWorkshop
{
    public enum XUI_NAMEDFRAME_COMMAND 
    {
        XUI_CMD_PLAY,
        XUI_CMD_STOP,
        XUI_CMD_GOTO,
        XUI_CMD_GOTOANDPLAY,
        XUI_CMD_GOTOANDSTOP,
        XUI_CMD_COUNT
    }
    public enum XUI_COMPOUND_PROPERTY
    {
        XUI_PROP_STROKE,
        XUI_PROP_GRADIENT,
        XUI_PROP_FILL
    }

    public enum XUI_INTERPOLATE
    {
        XUI_INTERPOLATE_LINEAR,
        XUI_INTERPOLATE_NONE,
        XUI_INTERPOLATE_EASE
    }

    public static class XuiNamedFrameCommandConvert
    {
        public static string ToString(this XUI_NAMEDFRAME_COMMAND c, int dummy)
        {
            string retVal = "";
            switch (c)
            {
                case XUI_NAMEDFRAME_COMMAND.XUI_CMD_PLAY:
                    retVal = "play";
                    break;
                case XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDSTOP:
                    retVal = "gotoandstop";
                    break;
                case XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDPLAY:
                    retVal = "gotoandplay";
                    break;
                case XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTO:
                    retVal = "goto";
                    break;
                case XUI_NAMEDFRAME_COMMAND.XUI_CMD_STOP:
                    retVal = "stop";
                        break;
            }
            return retVal;
        }
        public static XUI_NAMEDFRAME_COMMAND ToXuiNamedFrameCommand(this string s)
        {
            switch (s)
            {
                case "play":
                    return XUI_NAMEDFRAME_COMMAND.XUI_CMD_PLAY;
                case "gotoandstop":
                    return XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDSTOP;
                case "gotoandplay":
                    return XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTOANDPLAY;
                case "goto":
                    return XUI_NAMEDFRAME_COMMAND.XUI_CMD_GOTO;
                case "stop":
                    return XUI_NAMEDFRAME_COMMAND.XUI_CMD_STOP;
            }

            return XUI_NAMEDFRAME_COMMAND.XUI_CMD_PLAY;
        }
    }
}
